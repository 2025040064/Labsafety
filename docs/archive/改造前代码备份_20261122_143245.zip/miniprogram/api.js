const base = 'http://127.0.0.1:8765'
const localHeaders = { 'X-Lab-Local': '1' }

function request(path, options = {}) {
  return new Promise((resolve, reject) => wx.request({
    url: base + path,
    method: options.method || 'GET',
    data: options.data,
    responseType: options.responseType || 'text',
    header: { 'content-type': options.contentType || 'application/json', ...localHeaders },
    success(res) {
      if (res.statusCode >= 200 && res.statusCode < 300) resolve(res.data)
      else reject(new Error((res.data && res.data.error) || '请求失败 ' + res.statusCode))
    },
    fail(error) { reject(new Error(error.errMsg || '无法连接后端')) }
  }))
}
module.exports = { request, base, localHeaders }
